import React from 'react';
import { motion } from 'framer-motion';
import { Phone, MessageSquare, Shield } from 'lucide-react';
import ZipCodeForm from '../components/ZipCodeForm';
import NumbersList from '../components/NumbersList';
import PurchaseButton from '../components/PurchaseButton';
import LoadingSpinner from '../components/LoadingSpinner';
import { useAppContext } from '../context/AppContext';

const Home: React.FC = () => {
  const { isLoading, error } = useAppContext();

  return (
    <div className="min-h-screen bg-gradient-to-b from-dark-900 to-dark-800">
      <section className="relative pb-32">
        <div className="max-w-4xl mx-auto pt-32 pb-20 px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight leading-tight"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            Bypass analyst review with a breeze #FeliciaCole
          </motion.h1>
          <motion.p 
            className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Choose up to 10 ports to help that check clear 😁
          </motion.p>
        </div>
      </section>

      <section className="relative -mt-32 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="bg-dark-800/80 backdrop-blur-lg shadow-2xl rounded-2xl px-6 py-8 sm:p-10 border border-dark-700/50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {isLoading ? (
            <div className="py-16 flex flex-col items-center">
              <LoadingSpinner size="large" />
              <p className="mt-4 text-gray-400">Searching for numbers...</p>
            </div>
          ) : (
            <>
              <ZipCodeForm />
              {error && (
                <div className="mt-4 bg-red-900/30 p-4 rounded-xl border border-red-700/50">
                  <p className="text-sm text-red-400">{error}</p>
                </div>
              )}
              <NumbersList />
              <PurchaseButton />
            </>
          )}
        </motion.div>
      </section>

      <section className="max-w-7xl mx-auto py-24 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white sm:text-5xl tracking-tight">
            Why choose Portly?
          </h2>
          <p className="mt-6 text-xl text-gray-400 max-w-2xl mx-auto">
            Because we're dope, and we do dope shit 💯
          </p>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          <motion.div 
            className="bg-dark-800/50 backdrop-blur shadow-xl rounded-2xl p-8 text-center border border-dark-700/50"
            whileHover={{ y: -5 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="rounded-full bg-primary-900/30 p-4 mx-auto w-fit ring-1 ring-primary-500/20">
              <Phone className="h-8 w-8 text-primary-400" />
            </div>
            <h3 className="mt-6 text-xl font-semibold text-white">One number for everything</h3>
            <p className="mt-4 text-gray-400 leading-relaxed">
              Use one number across all your devices - mobile, tablet, or desktop.
            </p>
          </motion.div>

          <motion.div 
            className="bg-dark-800/50 backdrop-blur shadow-xl rounded-2xl p-8 text-center border border-dark-700/50"
            whileHover={{ y: -5 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="rounded-full bg-primary-900/30 p-4 mx-auto w-fit ring-1 ring-primary-500/20">
              <MessageSquare className="h-8 w-8 text-primary-400" />
            </div>
            <h3 className="mt-6 text-xl font-semibold text-white">Smart messaging</h3>
            <p className="mt-4 text-gray-400 leading-relaxed">
              Send and receive texts from any device with smart features.
            </p>
          </motion.div>

          <motion.div 
            className="bg-dark-800/50 backdrop-blur shadow-xl rounded-2xl p-8 text-center border border-dark-700/50"
            whileHover={{ y: -5 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="rounded-full bg-primary-900/30 p-4 mx-auto w-fit ring-1 ring-primary-500/20">
              <Shield className="h-8 w-8 text-primary-400" />
            </div>
            <h3 className="mt-6 text-xl font-semibold text-white">Privacy protection</h3>
            <p className="mt-4 text-gray-400 leading-relaxed">
              Keep your personal number private with call screening and blocking.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;