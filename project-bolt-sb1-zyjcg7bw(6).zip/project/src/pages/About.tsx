import React from 'react';
import { motion } from 'framer-motion';
import { Phone, MessageSquare, Shield, Globe, Clock, CreditCard } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-dark-900 to-dark-800 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-white sm:text-5xl tracking-tight mb-6">
            About Portly
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Portly is your trusted partner for seamless phone number management. We make it easy to get and manage virtual phone numbers that work across all your devices.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-dark-800/50 backdrop-blur shadow-xl rounded-2xl p-8 border border-dark-700/50"
            >
              <div className="rounded-full bg-primary-900/30 p-4 w-fit ring-1 ring-primary-500/20 mb-6">
                <feature.icon className="h-6 w-6 text-primary-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="bg-dark-800/50 backdrop-blur rounded-2xl p-8 md:p-12 border border-dark-700/50"
        >
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Our Mission</h2>
            <p className="text-lg text-gray-300 leading-relaxed mb-8">
              At Portly, we believe in making communication technology accessible and efficient. Our platform is designed to help individuals and businesses manage their phone numbers with ease, ensuring reliable connectivity across all devices.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <div className="text-2xl font-bold text-primary-400">100+</div>
              <div className="text-gray-400">|</div>
              <div className="text-2xl font-bold text-primary-400">24/7</div>
              <div className="text-gray-400">|</div>
              <div className="text-2xl font-bold text-primary-400">Global</div>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-2">
              <div className="text-sm text-gray-400">Area Codes</div>
              <div className="hidden sm:block text-gray-400">•</div>
              <div className="text-sm text-gray-400">Support</div>
              <div className="hidden sm:block text-gray-400">•</div>
              <div className="text-sm text-gray-400">Coverage</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

const features = [
  {
    icon: Phone,
    title: "Universal Access",
    description: "Use your numbers on any device - mobile, tablet, or desktop. Stay connected wherever you go."
  },
  {
    icon: MessageSquare,
    title: "Smart Messaging",
    description: "Powerful messaging features including auto-replies, scheduled messages, and group conversations."
  },
  {
    icon: Shield,
    title: "Enhanced Privacy",
    description: "Keep your personal number private with advanced call screening and blocking features."
  },
  {
    icon: Globe,
    title: "Global Reach",
    description: "Access numbers from multiple countries and regions to establish your global presence."
  },
  {
    icon: Clock,
    title: "Instant Setup",
    description: "Get your new number in minutes with our streamlined provisioning process."
  },
  {
    icon: CreditCard,
    title: "Flexible Pricing",
    description: "Choose from various plans that fit your needs, with no hidden fees or long-term contracts."
  }
];

export default About;