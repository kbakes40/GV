import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, ArrowRight, Upload } from 'lucide-react';
import NumbersList from '../components/NumbersList';
import PortingForm from '../components/PortingForm';
import { useAppContext } from '../context/AppContext';

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'purchase' | 'port'>('purchase');
  const { isLoading, error } = useAppContext();

  return (
    <div className="min-h-screen bg-gradient-to-b from-dark-900 to-dark-800 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-12">
          <h1 className="text-4xl font-bold text-white">Number Management</h1>
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('purchase')}
              className={`px-6 py-3 rounded-lg transition-colors ${
                activeTab === 'purchase'
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-300 hover:bg-dark-600'
              }`}
            >
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                <span>Purchase Numbers</span>
              </div>
            </button>
            <button
              onClick={() => setActiveTab('port')}
              className={`px-6 py-3 rounded-lg transition-colors ${
                activeTab === 'port'
                  ? 'bg-primary-600 text-white'
                  : 'bg-dark-700 text-gray-300 hover:bg-dark-600'
              }`}
            >
              <div className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                <span>Port Numbers</span>
              </div>
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-8 bg-red-900/30 border border-red-700/50 rounded-lg p-4">
            <p className="text-red-400">{error}</p>
          </div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {activeTab === 'purchase' ? (
            <NumbersList />
          ) : (
            <PortingForm />
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;