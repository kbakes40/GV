import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Copy, Phone, MessageSquare, Key } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { formatPhoneNumber } from '../utils/formatPhoneNumber';
import BottomNav from '../components/BottomNav';
import Dialer from '../components/Dialer';

const Success: React.FC = () => {
  const { account } = useAppContext();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'phone' | 'sms' | 'pop'>('phone');
  const [selectedNumber, setSelectedNumber] = useState<string | null>(null);

  useEffect(() => {
    if (!account) {
      navigate('/');
    } else if (!selectedNumber && account.phoneNumbers.length > 0) {
      setSelectedNumber(account.phoneNumbers[0]);
    }
  }, [account, navigate, selectedNumber]);

  if (!account) {
    return null;
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'phone':
        return (
          <div className="space-y-6">
            <div className="space-y-3">
              {account.phoneNumbers.map((phoneNumber) => (
                <button
                  key={phoneNumber}
                  onClick={() => setSelectedNumber(phoneNumber)}
                  className={`w-full flex items-center justify-between bg-dark-700 px-4 py-3 rounded-md transition-colors ${
                    selectedNumber === phoneNumber ? 'ring-2 ring-primary-500' : ''
                  }`}
                >
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-3" />
                    <span className="text-lg font-semibold text-white">
                      {formatPhoneNumber(phoneNumber.slice(2))}
                    </span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      copyToClipboard(phoneNumber);
                    }}
                    className="text-primary-400 hover:text-primary-300 transition-colors"
                    title="Copy to clipboard"
                  >
                    <Copy className="h-5 w-5" />
                  </button>
                </button>
              ))}
            </div>
            
            {selectedNumber && (
              <Dialer fromNumber={selectedNumber} />
            )}
          </div>
        );
      
      case 'sms':
        return (
          <div className="bg-dark-700 rounded-md p-4">
            <div className="flex items-center mb-4">
              <MessageSquare className="h-5 w-5 text-primary-400 mr-2" />
              <h3 className="text-lg font-medium text-white">SMS Capabilities</h3>
            </div>
            <p className="text-gray-400">
              All your numbers support SMS messaging. You can send and receive messages through the Twilio API or dashboard.
            </p>
          </div>
        );
      
      case 'pop':
        return (
          <div className="space-y-4">
            <div className="bg-dark-700 rounded-md p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Key className="h-5 w-5 text-primary-400 mr-2" />
                  <span className="text-gray-400">Port Out PIN:</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="font-mono text-white">{account.pin}</span>
                  <button
                    onClick={() => copyToClipboard(account.pin)}
                    className="text-primary-400 hover:text-primary-300 transition-colors"
                    title="Copy PIN"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <p className="text-sm text-gray-400 mt-2">
                Use this PIN when you need to transfer your numbers to another provider.
              </p>
            </div>
            
            <div className="bg-yellow-900/20 rounded-md p-4 border border-yellow-700/50">
              <p className="text-sm text-yellow-200">
                <strong>Important:</strong> Keep your Port Out PIN secure. You'll need it to port your numbers to another carrier.
              </p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-dark-900 py-12 pb-24">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="bg-dark-800 shadow-lg rounded-lg overflow-hidden border border-dark-700"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="bg-primary-600 px-6 py-8 text-center">
            <CheckCircle className="mx-auto h-16 w-16 text-white" />
            <h1 className="mt-4 text-2xl font-bold text-white">Success!</h1>
            <p className="mt-2 text-primary-100">
              Your new phone numbers have been provisioned
            </p>
          </div>
          
          <div className="px-6 py-8">
            <div className="mb-8">
              <h2 className="text-xl font-medium text-white mb-4">Your Numbers</h2>
              {renderTabContent()}
            </div>
            
            <div className="mt-8 text-center">
              <motion.button
                onClick={() => navigate('/')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
              >
                Return to Home
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
      
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Success;