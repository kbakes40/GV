import React, { useState, useEffect } from 'react';
import { Send, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';
import { sendMessage } from '../services/twilioService';
import { io } from 'socket.io-client';

interface MessageComposerProps {
  fromNumber: string;
}

interface Message {
  id: string;
  from: string;
  to: string;
  body: string;
  timestamp: Date;
  direction: 'inbound' | 'outbound';
}

const MessageComposer: React.FC<MessageComposerProps> = ({ fromNumber }) => {
  const [recipient, setRecipient] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    const socket = io('http://localhost:3000');

    socket.on('connect', () => {
      console.log('Connected to WebSocket');
      socket.emit('subscribe', fromNumber);
    });

    socket.on('message', (newMessage: Message) => {
      setMessages(prev => [...prev, newMessage]);
    });

    return () => {
      socket.disconnect();
    };
  }, [fromNumber]);

  const handleSend = async () => {
    if (!recipient || !message) {
      setError('Please enter both recipient number and message');
      return;
    }

    setIsSending(true);
    setError(null);
    setStatus('Sending message...');

    try {
      const formattedNumber = recipient.startsWith('+') 
        ? recipient 
        : `+1${recipient.replace(/\D/g, '')}`;
      
      const result = await sendMessage(fromNumber, formattedNumber, message);
      
      const newMessage: Message = {
        id: result.sid,
        from: fromNumber,
        to: formattedNumber,
        body: message,
        timestamp: new Date(),
        direction: 'outbound'
      };

      setMessages(prev => [...prev, newMessage]);
      setStatus(`Message sent: ${result.status}`);
      
      setRecipient('');
      setMessage('');
      setTimeout(() => setStatus(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to send message');
      setStatus(null);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-dark-700 rounded-xl p-6"
    >
      <div className="space-y-6">
        <div className="flex-1 overflow-y-auto max-h-96 space-y-4 mb-6">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  msg.direction === 'outbound'
                    ? 'bg-primary-600 text-white ml-auto'
                    : 'bg-dark-600 text-gray-200'
                }`}
              >
                <p className="text-sm">{msg.body}</p>
                <p className="text-xs mt-1 opacity-75">
                  {new Date(msg.timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div>
          <label htmlFor="recipient" className="block text-sm font-medium text-gray-400 mb-1">
            Recipient Number
          </label>
          <input
            type="tel"
            id="recipient"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            placeholder="+1 (555) 555-5555"
            className="w-full bg-dark-800 text-white py-2 px-3 rounded-lg focus:ring-2 focus:ring-primary-500 focus:outline-none"
          />
        </div>

        <div>
          <label htmlFor="message" className="block text-sm font-medium text-gray-400 mb-1">
            Message
          </label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message here..."
            rows={4}
            className="w-full bg-dark-800 text-white py-2 px-3 rounded-lg focus:ring-2 focus:ring-primary-500 focus:outline-none resize-none"
          />
        </div>

        {error && (
          <p className="text-red-400 text-sm">{error}</p>
        )}
        {status && (
          <p className="text-primary-400 text-sm">{status}</p>
        )}

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSend}
          disabled={isSending || !recipient || !message}
          className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send className="h-5 w-5" />
          <span>{isSending ? 'Sending...' : 'Send Message'}</span>
        </motion.button>
      </div>
    </motion.div>
  );
};

export default MessageComposer;