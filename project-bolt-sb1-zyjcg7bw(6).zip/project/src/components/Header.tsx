import React from 'react';
import { Phone, Home, Info, HelpCircle } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Header: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-dark-800 border-b border-dark-700 fixed top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link 
            to="/" 
            className="flex items-center space-x-3 hover:opacity-90 transition-all duration-200"
          >
            <Phone className="h-8 w-8 text-primary-500" />
            <span className="text-xl font-medium text-white">Portly</span>
          </Link>
          
          <nav className="flex items-center space-x-6">
            <Link 
              to="/" 
              className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                isActive('/') 
                  ? 'text-white bg-dark-700' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-700/50'
              }`}
            >
              <Home className="h-4 w-4" />
              <span>Home</span>
            </Link>
            <Link 
              to="/about" 
              className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                isActive('/about') 
                  ? 'text-white bg-dark-700' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-700/50'
              }`}
            >
              <Info className="h-4 w-4" />
              <span>About</span>
            </Link>
            <Link 
              to="/support" 
              className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                isActive('/support') 
                  ? 'text-white bg-dark-700' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-700/50'
              }`}
            >
              <HelpCircle className="h-4 w-4" />
              <span>Support</span>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;