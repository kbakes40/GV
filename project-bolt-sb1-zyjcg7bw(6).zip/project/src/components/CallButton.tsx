import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { createCall } from '../services/twilioService';

interface CallButtonProps {
  from: string;
  to: string;
}

const CallButton: React.FC<CallButtonProps> = ({ from, to }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCall = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const call = await createCall(from, to);
      console.log('Call initiated:', call.sid);
    } catch (err: any) {
      setError(err.message || 'Failed to initiate call');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative">
      <motion.button
        onClick={handleCall}
        disabled={isLoading}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={`flex items-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors ${
          isLoading ? 'opacity-75 cursor-not-allowed' : ''
        }`}
      >
        <Phone className="h-4 w-4" />
        <span>{isLoading ? 'Initiating call...' : 'Call'}</span>
      </motion.button>
      
      {error && (
        <div className="absolute top-full left-0 right-0 mt-2 p-2 bg-red-900/30 border border-red-700/50 rounded text-sm text-red-400">
          {error}
        </div>
      )}
    </div>
  );
};

export default CallButton;