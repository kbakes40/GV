import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { purchasePhoneNumber } from '../services/twilioService';

const PurchaseButton: React.FC = () => {
  const { 
    selectedNumbers, 
    setAccount, 
    setIsLoading, 
    setError 
  } = useAppContext();
  const navigate = useNavigate();

  const handlePurchase = async () => {
    if (selectedNumbers.length === 0) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const account = await purchasePhoneNumber(selectedNumbers.map(n => n.phoneNumber));
      setAccount(account);
      navigate('/success');
    } catch (error) {
      setError('Failed to purchase the phone numbers. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (selectedNumbers.length === 0) {
    return null;
  }

  const totalCost = selectedNumbers.length * 10;

  return (
    <motion.div
      className="mt-12"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.button
        onClick={handlePurchase}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full py-4 px-6 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-xl shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors flex items-center justify-center text-lg"
      >
        <ShoppingCart className="h-6 w-6 mr-3" />
        Purchase {selectedNumbers.length} number{selectedNumbers.length > 1 ? 's' : ''}
      </motion.button>
      <p className="mt-3 text-base text-gray-400 text-center">
        Total cost: ${totalCost.toFixed(2)}
      </p>
    </motion.div>
  );
};

export default PurchaseButton;