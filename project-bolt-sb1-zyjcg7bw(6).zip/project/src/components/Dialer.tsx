import React, { useState } from 'react';
import { Phone, X, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { createCall } from '../services/twilioService';

interface DialerProps {
  fromNumber: string;
}

const Dialer: React.FC<DialerProps> = ({ fromNumber }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isDialing, setIsDialing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [callStatus, setCallStatus] = useState<string | null>(null);

  const handleNumberClick = (num: string) => {
    if (phoneNumber.length < 15) {
      setPhoneNumber(prev => prev + num);
    }
  };

  const handleBackspace = () => {
    setPhoneNumber(prev => prev.slice(0, -1));
  };

  const handleCall = async () => {
    if (phoneNumber.length < 10) {
      setError('Please enter a valid phone number');
      return;
    }

    setIsDialing(true);
    setError(null);
    setCallStatus('Initiating call...');

    try {
      const formattedNumber = phoneNumber.startsWith('+') 
        ? phoneNumber 
        : `+1${phoneNumber.replace(/\D/g, '')}`;
      
      const call = await createCall(fromNumber, formattedNumber);
      setCallStatus(`Call Status: ${call.status}`);
      
      // Reset after successful call
      setTimeout(() => {
        setPhoneNumber('');
        setCallStatus(null);
      }, 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to place call');
      setCallStatus(null);
    } finally {
      setIsDialing(false);
    }
  };

  const dialPad = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['*', '0', '#']
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-dark-700 rounded-xl p-6"
    >
      <div className="mb-6">
        <input
          type="text"
          value={phoneNumber}
          readOnly
          placeholder="Enter phone number"
          className="w-full bg-dark-800 text-white text-2xl py-3 px-4 rounded-lg text-center font-mono"
        />
        {error && (
          <p className="text-red-400 text-sm mt-2 text-center">{error}</p>
        )}
        {callStatus && (
          <p className="text-primary-400 text-sm mt-2 text-center">{callStatus}</p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {dialPad.map((row, rowIndex) => (
          <React.Fragment key={rowIndex}>
            {row.map((num) => (
              <motion.button
                key={num}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleNumberClick(num)}
                className="bg-dark-600 hover:bg-dark-500 text-white rounded-lg p-4 text-2xl font-medium transition-colors"
              >
                {num}
              </motion.button>
            ))}
          </React.Fragment>
        ))}
      </div>

      <div className="flex justify-center space-x-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleBackspace}
          disabled={!phoneNumber.length}
          className="bg-dark-600 hover:bg-dark-500 text-white rounded-full p-4 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <X className="h-6 w-6" />
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleCall}
          disabled={isDialing || phoneNumber.length < 10}
          className={`rounded-full p-4 transition-colors ${
            isDialing
              ? 'bg-red-600 hover:bg-red-700'
              : 'bg-primary-600 hover:bg-primary-700'
          } text-white disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          {isDialing ? (
            <X className="h-6 w-6" />
          ) : (
            <Phone className="h-6 w-6" />
          )}
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => handleNumberClick('+')}
          disabled={phoneNumber.length > 0}
          className="bg-dark-600 hover:bg-dark-500 text-white rounded-full p-4 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <Plus className="h-6 w-6" />
        </motion.button>
      </div>
    </motion.div>
  );
};

export default Dialer;