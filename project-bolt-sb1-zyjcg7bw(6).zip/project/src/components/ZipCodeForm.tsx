import React from 'react';
import { motion } from 'framer-motion';
import { useAppContext } from '../context/AppContext';
import { listOwnedNumbers } from '../services/twilioService';
import { Phone, RefreshCw } from 'lucide-react';

const OwnedNumbersSearch: React.FC = () => {
  const { 
    setAvailableNumbers, 
    setIsLoading, 
    setError 
  } = useAppContext();

  const handleFetchNumbers = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const numbers = await listOwnedNumbers();
      if (numbers.length === 0) {
        setError('No phone numbers found in inventory');
        return;
      }
      setAvailableNumbers(numbers);
    } catch (error: any) {
      setError(error.message || 'Failed to fetch inventory');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div 
      className="max-w-md mx-auto bg-dark-800/50 backdrop-blur-sm rounded-2xl p-8 border border-dark-700/50"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary-900/30 ring-1 ring-primary-500/20 mb-4">
          <Phone className="h-8 w-8 text-primary-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">
          KB Port Inventory
        </h2>
        <p className="text-gray-400 text-sm">
          Access your available port inventory with a single click
        </p>
      </div>
      
      <motion.button
        onClick={handleFetchNumbers}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full flex items-center justify-center space-x-3 py-4 px-6 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-xl shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors text-lg"
      >
        <RefreshCw className="h-5 w-5" />
        <span>Refresh Inventory</span>
      </motion.button>
    </motion.div>
  );
};

export default OwnedNumbersSearch;