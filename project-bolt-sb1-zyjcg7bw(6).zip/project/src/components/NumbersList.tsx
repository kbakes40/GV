import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Check, Phone, MessageSquare, Shield, MapPin } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { PhoneNumber } from '../types';

const NumbersList: React.FC = () => {
  const { 
    availableNumbers, 
    selectedNumbers,
    setSelectedNumbers
  } = useAppContext();

  const numbersByZip = useMemo(() => {
    const grouped = availableNumbers.reduce((acc, number) => {
      // Extract ZIP code from phone number (area code)
      const areaCode = number.phoneNumber.slice(2, 5);
      if (!acc[areaCode]) {
        acc[areaCode] = [];
      }
      acc[areaCode].push(number);
      return acc;
    }, {} as Record<string, PhoneNumber[]>);

    // Sort ZIP codes
    return Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b));
  }, [availableNumbers]);

  if (availableNumbers.length === 0) {
    return null;
  }

  const handleSelectNumber = (number: PhoneNumber) => {
    const isSelected = selectedNumbers.some(n => n.phoneNumber === number.phoneNumber);
    
    if (isSelected) {
      setSelectedNumbers(selectedNumbers.filter(n => n.phoneNumber !== number.phoneNumber));
    } else if (selectedNumbers.length < 10) {
      setSelectedNumbers([...selectedNumbers, number]);
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      className="mt-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">
            Available Numbers
          </h2>
          <p className="text-gray-400 text-sm">
            Select up to 10 numbers to process
          </p>
        </div>
        <span className="px-4 py-2 bg-primary-900/30 text-primary-400 text-sm font-medium rounded-full ring-1 ring-primary-500/20">
          {selectedNumbers.length}/10 selected
        </span>
      </div>
      
      <motion.div 
        className="space-y-8"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {numbersByZip.map(([areaCode, numbers]) => (
          <div key={areaCode} className="space-y-4">
            <div className="flex items-center space-x-3 text-gray-400">
              <MapPin className="h-5 w-5" />
              <h3 className="text-lg font-medium">Area Code {areaCode}</h3>
              <span className="text-sm">({numbers.length} numbers)</span>
            </div>
            
            <div className="space-y-4">
              {numbers.map((number) => {
                const isSelected = selectedNumbers.some(n => n.phoneNumber === number.phoneNumber);
                const capabilities = number.capabilities || {
                  voice: true,
                  sms: true,
                  mms: true
                };
                
                return (
                  <motion.div 
                    key={number.phoneNumber}
                    variants={item}
                    whileHover={{ scale: 1.01 }}
                  >
                    <button
                      onClick={() => handleSelectNumber(number)}
                      className={`w-full p-6 rounded-xl flex items-center justify-between transition-all ${
                        isSelected
                          ? 'bg-primary-900/20 border border-primary-700/50 ring-1 ring-primary-500/20'
                          : 'bg-dark-800/50 backdrop-blur-sm border border-dark-700/50 hover:border-dark-500/50'
                      }`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center space-x-4">
                          <div className="rounded-full bg-dark-700/50 p-2">
                            <Phone className="h-5 w-5 text-primary-400" />
                          </div>
                          <span className="text-xl font-semibold text-white">
                            {number.formattedNumber}
                          </span>
                        </div>
                        
                        <div className="mt-3 flex items-center space-x-6 text-sm">
                          {capabilities.voice && (
                            <span className="flex items-center space-x-2 text-gray-400">
                              <Phone className="h-4 w-4" />
                              <span>Voice Ready</span>
                            </span>
                          )}
                          {capabilities.sms && (
                            <span className="flex items-center space-x-2 text-gray-400">
                              <MessageSquare className="h-4 w-4" />
                              <span>SMS Enabled</span>
                            </span>
                          )}
                          <span className="flex items-center space-x-2 text-gray-400">
                            <Shield className="h-4 w-4" />
                            <span>Protected</span>
                          </span>
                        </div>
                      </div>
                      
                      <div className={`rounded-full p-2 transition-colors ${
                        isSelected ? 'bg-primary-500/20' : 'bg-dark-700/50'
                      }`}>
                        <Check className={`h-5 w-5 ${
                          isSelected ? 'text-primary-400' : 'text-gray-500'
                        }`} />
                      </div>
                    </button>
                  </motion.div>
                );
              })}
            </div>
          </div>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default NumbersList;