import React from 'react';
import { Phone, Key } from 'lucide-react';
import { motion } from 'framer-motion';

interface BottomNavProps {
  activeTab: 'phone' | 'pop';
  onTabChange: (tab: 'phone' | 'pop') => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  return (
    <motion.div 
      className="fixed bottom-0 left-0 right-0 bg-dark-800/95 backdrop-blur-lg border-t border-dark-700 px-4 py-2 z-50"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className="max-w-xl mx-auto flex justify-around items-center">
        <button
          onClick={() => onTabChange('phone')}
          className={`flex flex-col items-center p-2 rounded-lg transition-colors ${
            activeTab === 'phone' 
              ? 'text-primary-400' 
              : 'text-gray-400 hover:text-gray-300'
          }`}
        >
          <Phone className="h-6 w-6" />
          <span className="text-xs mt-1">Phone</span>
        </button>
        
        <button
          onClick={() => onTabChange('pop')}
          className={`flex flex-col items-center p-2 rounded-lg transition-colors ${
            activeTab === 'pop' 
              ? 'text-primary-400' 
              : 'text-gray-400 hover:text-gray-300'
          }`}
        >
          <Key className="h-6 w-6" />
          <span className="text-xs mt-1">POP</span>
        </button>
      </div>
    </motion.div>
  );
};

export default BottomNav;