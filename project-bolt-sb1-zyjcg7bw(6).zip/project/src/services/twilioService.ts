import axios from 'axios';
import { twilioConfig } from '../config/twilio';
import { PhoneNumber, Account, CallDetails, OwnedPhoneNumber } from '../types';
import { formatPhoneNumber, generatePin } from '../utils/formatPhoneNumber';

const twilioBaseUrl = 'https://api.twilio.com/2010-04-01';
const { accountSid, authToken } = twilioConfig;
const auth = btoa(`${accountSid}:${authToken}`);

const apiBaseUrl = import.meta.env.PROD 
  ? 'https://your-netlify-url.netlify.app/api'
  : 'http://localhost:3000/api';

export async function sendMessage(from: string, to: string, body: string) {
  try {
    const response = await axios.post(
      `${twilioBaseUrl}/Accounts/${accountSid}/Messages.json`,
      new URLSearchParams({
        From: from,
        To: to,
        Body: body
      }),
      {
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    return {
      sid: response.data.sid,
      status: response.data.status,
      body: response.data.body
    };
  } catch (error: any) {
    console.error('Error sending message:', error);
    throw new Error(error.response?.data?.message || 'Failed to send message');
  }
}

export async function listOwnedNumbers(): Promise<OwnedPhoneNumber[]> {
  try {
    const response = await axios.get(
      `${twilioBaseUrl}/Accounts/${accountSid}/IncomingPhoneNumbers.json`,
      {
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.data?.incoming_phone_numbers?.length) {
      return [];
    }

    return response.data.incoming_phone_numbers.map((number: any) => ({
      phoneNumber: number.phone_number,
      formattedNumber: formatPhoneNumber(number.phone_number.slice(2)),
      dateCreated: number.date_created,
      capabilities: {
        voice: number.capabilities?.voice || false,
        sms: number.capabilities?.sms || false,
        mms: number.capabilities?.mms || false
      }
    }));
  } catch (error: any) {
    console.error('Error listing owned numbers:', error);
    throw new Error(error.response?.data?.message || 'Failed to list owned numbers');
  }
}

export async function searchPhoneNumbers(areaCode: string): Promise<PhoneNumber[]> {
  try {
    const response = await axios.get(
      `${twilioBaseUrl}/Accounts/${accountSid}/AvailablePhoneNumbers/US/Local.json`,
      {
        params: {
          AreaCode: areaCode,
          Limit: 10,
          SmsEnabled: true,
          VoiceEnabled: true,
        },
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.data.available_phone_numbers?.length) {
      throw new Error('No phone numbers available in this area code');
    }

    return response.data.available_phone_numbers.map((number: any) => ({
      phoneNumber: number.phone_number,
      formattedNumber: formatPhoneNumber(number.phone_number.slice(2)),
      capabilities: {
        voice: true,
        sms: true,
        mms: true
      }
    }));
  } catch (error: any) {
    console.error('Error searching phone numbers:', error);
    throw new Error(error.response?.data?.message || 'Failed to search for phone numbers');
  }
}

export async function purchasePhoneNumber(phoneNumbers: string[]): Promise<Account> {
  try {
    const purchasedNumbers = await Promise.all(
      phoneNumbers.map(phoneNumber =>
        axios.post(
          `${twilioBaseUrl}/Accounts/${accountSid}/IncomingPhoneNumbers.json`,
          new URLSearchParams({ 
            PhoneNumber: phoneNumber,
            VoiceUrl: `${apiBaseUrl}/call-handler`,
            StatusCallback: `${apiBaseUrl}/call-status`,
            VoiceMethod: 'POST',
            StatusCallbackMethod: 'POST'
          }),
          {
            headers: {
              Authorization: `Basic ${auth}`,
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          }
        )
      )
    );

    return {
      phoneNumbers: purchasedNumbers.map(response => response.data.phone_number),
      accountId: accountSid,
      pin: generatePin()
    };
  } catch (error: any) {
    console.error('Error purchasing phone numbers:', error);
    throw new Error(error.response?.data?.message || 'Failed to purchase phone numbers');
  }
}

export async function createCall(from: string, to: string): Promise<CallDetails> {
  try {
    // Ensure phone numbers are in E.164 format
    const formattedFrom = from.startsWith('+') ? from : `+1${from.replace(/\D/g, '')}`;
    const formattedTo = to.startsWith('+') ? to : `+1${to.replace(/\D/g, '')}`;

    if (!formattedFrom.match(/^\+1\d{10}$/) || !formattedTo.match(/^\+1\d{10}$/)) {
      throw new Error('Invalid phone number format. Must be a valid US/Canada number.');
    }

    const response = await axios.post(
      `${twilioBaseUrl}/Accounts/${accountSid}/Calls.json`,
      new URLSearchParams({
        From: formattedFrom,
        To: formattedTo,
        Url: `${apiBaseUrl}/call-handler`,
        RecordingEnabled: 'true',
        RecordingStatusCallback: `${apiBaseUrl}/recording-status`
      }),
      {
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    return {
      sid: response.data.sid,
      from: response.data.from,
      to: response.data.to,
      status: response.data.status
    };
  } catch (error: any) {
    console.error('Error creating call:', error);
    const errorMessage = error.response?.data?.message || error.response?.data?.error_message || 'Failed to create call';
    throw new Error(errorMessage);
  }
}

export async function initiatePortRequest(formData: {
  phoneNumber: string;
  carrier: string;
  accountNumber: string;
  pin: string;
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  state: string;
  zip: string;
}): Promise<{
  sid: string;
  status: string;
  phoneNumbers: string[];
}> {
  try {
    const response = await axios.post(
      `${twilioBaseUrl}/Accounts/${accountSid}/PortingRequests.json`,
      new URLSearchParams({
        PhoneNumbers: formData.phoneNumber,
        CarrierName: formData.carrier,
        AccountNumber: formData.accountNumber,
        Pin: formData.pin,
        FirstName: formData.firstName,
        LastName: formData.lastName,
        StreetAddress: formData.address,
        City: formData.city,
        State: formData.state,
        PostalCode: formData.zip,
      }),
      {
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    return {
      sid: response.data.sid,
      status: response.data.status,
      phoneNumbers: [formData.phoneNumber]
    };
  } catch (error: any) {
    console.error('Error initiating port request:', error);
    throw new Error(error.response?.data?.message || 'Failed to initiate port request');
  }
}