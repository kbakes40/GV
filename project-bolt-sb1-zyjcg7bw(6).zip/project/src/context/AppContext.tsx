import React, { createContext, useContext, useState, ReactNode } from 'react';
import { PhoneNumber, Account } from '../types';

interface AppContextType {
  selectedZipCode: string;
  setSelectedZipCode: (zipCode: string) => void;
  availableNumbers: PhoneNumber[];
  setAvailableNumbers: (numbers: PhoneNumber[]) => void;
  selectedNumbers: PhoneNumber[];
  setSelectedNumbers: (numbers: PhoneNumber[]) => void;
  account: Account | null;
  setAccount: (account: Account | null) => void;
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;
  error: string | null;
  setError: (error: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [selectedZipCode, setSelectedZipCode] = useState('');
  const [availableNumbers, setAvailableNumbers] = useState<PhoneNumber[]>([]);
  const [selectedNumbers, setSelectedNumbers] = useState<PhoneNumber[]>([]);
  const [account, setAccount] = useState<Account | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <AppContext.Provider
      value={{
        selectedZipCode,
        setSelectedZipCode,
        availableNumbers,
        setAvailableNumbers,
        selectedNumbers,
        setSelectedNumbers,
        account,
        setAccount,
        isLoading,
        setIsLoading,
        error,
        setError,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};