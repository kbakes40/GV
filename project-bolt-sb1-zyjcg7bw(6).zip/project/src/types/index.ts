export interface PhoneNumber {
  phoneNumber: string;
  formattedNumber: string;
  selected?: boolean;
  capabilities?: {
    voice: boolean;
    sms: boolean;
    mms: boolean;
  };
}

export interface Account {
  phoneNumbers: string[];
  accountId: string;
  pin: string;
}

export interface TwilioConfig {
  accountSid: string;
  authToken: string;
}

export interface CallDetails {
  sid: string;
  from: string;
  to: string;
  status: 'queued' | 'ringing' | 'in-progress' | 'completed' | 'failed';
  recording?: {
    sid: string;
    url: string;
    status: string;
  };
}

export interface OwnedPhoneNumber {
  phoneNumber: string;
  formattedNumber: string;
  dateCreated: string;
  capabilities: {
    voice: boolean;
    sms: boolean;
    mms: boolean;
  };
}