import { TwilioConfig } from '../types';

// This is now just a type-safe way to access environment variables
export const twilioConfig: TwilioConfig = {
  accountSid: import.meta.env.VITE_TWILIO_ACCOUNT_SID || 'mock_account_sid',
  authToken: import.meta.env.VITE_TWILIO_AUTH_TOKEN || 'mock_auth_token'
};