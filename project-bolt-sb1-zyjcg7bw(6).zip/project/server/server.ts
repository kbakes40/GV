import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { createServer } from 'http';
import { Server } from 'socket.io';
import callHandler from './api/call-handler';
import handleDigit from './api/handle-digit';
import recordingStatus from './api/recording-status';
import transcriptionStatus from './api/transcription-status';
import messageHandler from './api/message-handler';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const port = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log('Client connected');

  socket.on('subscribe', (phoneNumber) => {
    socket.join(phoneNumber);
    console.log(`Subscribed to messages for ${phoneNumber}`);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Add WebSocket instance to request object
app.use((req: any, res, next) => {
  req.io = io;
  next();
});

// Mount the API routes
app.use('/api', callHandler);
app.use('/api', handleDigit);
app.use('/api', recordingStatus);
app.use('/api', transcriptionStatus);
app.use('/api', messageHandler);

httpServer.listen(port, () => {
  console.log(`Server running on port ${port}`);
});