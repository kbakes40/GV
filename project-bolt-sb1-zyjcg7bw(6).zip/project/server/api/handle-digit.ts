import express from 'express';
import twilio from 'twilio';
import VoiceResponse = twilio.twiml.VoiceResponse;

const router = express.Router();

router.post('/handle-digit', (req, res) => {
  const twiml = new VoiceResponse();
  const { Digits, CallSid } = req.body;

  console.log(`Handling digit ${Digits} for call ${CallSid}`);

  try {
    switch (Digits) {
      case '1':
        // Handle voicemail
        twiml.say({
          voice: 'alice',
          language: 'en-US'
        }, 'Please leave your message after the beep.');
        
        twiml.record({
          maxLength: 300,
          playBeep: true,
          recordingStatusCallback: '/api/recording-status',
          transcribe: true,
          transcribeCallback: '/api/transcription-status',
          timeout: 10
        });
        break;
      
      case '2':
        // Try another number
        twiml.say({
          voice: 'alice',
          language: 'en-US'
        }, 'Transferring your call to an alternative number.');
        
        twiml.dial({
          callerId: req.body.From,
          record: 'record-from-answer',
          recordingStatusCallback: '/api/recording-status'
        }, '+1234567890'); // Replace with actual fallback number
        break;
      
      default:
        twiml.say({
          voice: 'alice',
          language: 'en-US'
        }, 'Invalid input received. Goodbye.');
        twiml.hangup();
    }

    res.type('text/xml');
    res.send(twiml.toString());
    
  } catch (error) {
    console.error('Error handling digit:', error);
    
    const errorTwiml = new VoiceResponse();
    errorTwiml.say({
      voice: 'alice',
      language: 'en-US'
    }, 'We apologize, but an error occurred. Please try again later.');
    
    errorTwiml.hangup();

    res.type('text/xml');
    res.status(200).send(errorTwiml.toString());
  }
});

export default router;