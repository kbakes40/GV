import express from 'express';

const router = express.Router();

router.post('/transcription-status', (req, res) => {
  const {
    TranscriptionSid,
    TranscriptionText,
    TranscriptionStatus,
    RecordingSid,
  } = req.body;

  console.log(`Transcription ${TranscriptionSid} for recording ${RecordingSid} is ${TranscriptionStatus}`);
  console.log(`Transcription text: ${TranscriptionText}`);

  // Here you could store the transcription in a database
  // or trigger notifications

  res.json({ success: true });
});

export default router;