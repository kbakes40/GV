import express from 'express';

const router = express.Router();

router.post('/recording-status', (req, res) => {
  const {
    RecordingSid,
    RecordingUrl,
    RecordingStatus,
    CallSid,
  } = req.body;

  console.log(`Recording ${RecordingSid} for call ${CallSid} is ${RecordingStatus}`);
  console.log(`Recording URL: ${RecordingUrl}`);

  // Here you could store the recording details in a database
  // or trigger additional processing

  res.json({ success: true });
});

export default router;