import express from 'express';
import twilio from 'twilio';
import VoiceResponse = twilio.twiml.VoiceResponse;

const router = express.Router();

router.post('/call-handler', (req, res) => {
  const twiml = new VoiceResponse();
  const { CallSid, From, To, Direction } = req.body;

  console.log(`Handling ${Direction} call from ${From} to ${To}`);

  try {
    if (Direction === 'inbound') {
      // Handle incoming calls with a simple menu
      twiml.say({
        voice: 'alice',
        language: 'en-US'
      }, 'Welcome to Portly.');

      twiml.pause({ length: 1 });

      const gather = twiml.gather({
        numDigits: 1,
        action: '/api/handle-digit',
        method: 'POST',
        timeout: 10
      });

      gather.say({
        voice: 'alice',
        language: 'en-US'
      }, 'Press 1 to leave a voicemail. Press 2 to try another number.');

      // If no input is received, replay the menu
      twiml.redirect({
        method: 'POST'
      }, '/api/call-handler');

    } else {
      // Handle outbound calls
      twiml.say({
        voice: 'alice',
        language: 'en-US'
      }, 'Your call is being connected. Please wait.');

      twiml.pause({ length: 1 });

      // Add dial verb for outbound calls
      twiml.dial({
        callerId: From,
        record: 'record-from-answer',
        recordingStatusCallback: '/api/recording-status'
      }, To);
    }

    res.type('text/xml');
    res.send(twiml.toString());

  } catch (error) {
    console.error('Error in call handler:', error);
    
    // Send a graceful error response
    const errorTwiml = new VoiceResponse();
    errorTwiml.say({
      voice: 'alice',
      language: 'en-US'
    }, 'We apologize, but an error occurred. Please try your call again later.');
    
    errorTwiml.pause({ length: 1 });
    errorTwiml.hangup();

    res.type('text/xml');
    res.status(200).send(errorTwiml.toString());
  }
});

export default router;