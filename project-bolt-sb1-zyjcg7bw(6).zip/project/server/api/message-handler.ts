import express from 'express';
import twilio from 'twilio';
import MessagingResponse = twilio.twiml.MessagingResponse;

const router = express.Router();

router.post('/message-handler', (req: any, res) => {
  const { Body, From, To, MessageSid } = req.body;
  const twiml = new MessagingResponse();

  console.log(`Received message from ${From} to ${To}: ${Body}`);

  try {
    // Emit the incoming message to connected clients
    if (req.io) {
      req.io.to(To).emit('message', {
        id: MessageSid,
        from: From,
        to: To,
        body: Body,
        timestamp: new Date(),
        direction: 'inbound'
      });
    }

    // Auto-reply for incoming messages
    twiml.message('Thank you for your message. We will get back to you shortly.');

    res.type('text/xml');
    res.send(twiml.toString());
  } catch (error) {
    console.error('Error handling message:', error);
    
    // Send a graceful error response
    const errorTwiml = new MessagingResponse();
    errorTwiml.message('We apologize, but an error occurred. Please try again later.');

    res.type('text/xml');
    res.status(200).send(errorTwiml.toString());
  }
});

export default router;