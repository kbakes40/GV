import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { Twilio } from "npm:twilio@4.19.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const twilioClient = new Twilio(
  Deno.env.get("TWILIO_ACCOUNT_SID")!,
  Deno.env.get("TWILIO_AUTH_TOKEN")!
);

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, areaCode, phoneNumbers } = await req.json();

    if (action === "search") {
      const numbers = await twilioClient.availablePhoneNumbers("US")
        .local.list({
          areaCode: parseInt(areaCode),
          limit: 10,
          smsEnabled: true,
          voiceEnabled: true,
        });

      return new Response(
        JSON.stringify({
          numbers: numbers.map((number) => ({
            phoneNumber: number.phoneNumber,
            formattedNumber: number.friendlyName,
          })),
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (action === "purchase") {
      const purchasedNumbers = await Promise.all(
        phoneNumbers.map((phoneNumber: string) =>
          twilioClient.incomingPhoneNumbers.create({
            phoneNumber,
            smsEnabled: true,
            voiceEnabled: true,
          })
        )
      );

      return new Response(
        JSON.stringify({
          phoneNumbers: purchasedNumbers.map((number) => number.phoneNumber),
          accountId: Deno.env.get("TWILIO_ACCOUNT_SID"),
          pin: Math.floor(100000 + Math.random() * 900000).toString(),
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});