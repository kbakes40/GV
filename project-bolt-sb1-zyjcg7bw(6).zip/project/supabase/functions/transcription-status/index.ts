import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const params = await req.formData();
    const transcriptionSid = params.get("TranscriptionSid");
    const transcriptionText = params.get("TranscriptionText");
    const transcriptionStatus = params.get("TranscriptionStatus");
    const recordingSid = params.get("RecordingSid");

    console.log(`Transcription ${transcriptionSid} for recording ${recordingSid} is ${transcriptionStatus}`);
    console.log(`Transcription text: ${transcriptionText}`);

    // Here you could store the transcription in a database
    // or trigger notifications

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error handling transcription status:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});