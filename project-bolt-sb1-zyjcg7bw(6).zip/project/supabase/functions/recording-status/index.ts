import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const params = await req.formData();
    const recordingSid = params.get("RecordingSid");
    const recordingUrl = params.get("RecordingUrl");
    const recordingStatus = params.get("RecordingStatus");
    const callSid = params.get("CallSid");

    console.log(`Recording ${recordingSid} for call ${callSid} is ${recordingStatus}`);
    console.log(`Recording URL: ${recordingUrl}`);

    // Here you could store the recording details in a database
    // or trigger additional processing

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error handling recording status:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});