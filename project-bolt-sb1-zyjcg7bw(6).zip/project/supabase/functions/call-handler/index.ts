import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get call parameters from the request
    const params = await req.formData();
    const callSid = params.get("CallSid");
    const from = params.get("From");
    const to = params.get("To");
    const direction = params.get("Direction");
    const recordingEnabled = params.get("RecordingEnabled") === "true";

    // Generate TwiML response
    let twiml = '<?xml version="1.0" encoding="UTF-8"?>\n<Response>\n';

    if (direction === "inbound") {
      // Handle incoming calls
      twiml += '  <Say>Welcome to Portly. Please wait while we connect your call.</Say>\n';
      twiml += '  <Play>https://api.twilio.com/cowbell.mp3</Play>\n';
      
      if (recordingEnabled) {
        twiml += '  <Record \n';
        twiml += '    maxLength="3600" \n';
        twiml += '    playBeep="true" \n';
        twiml += '    recordingStatusCallback="/recording-status" \n';
        twiml += '    action="/handle-recording" \n';
        twiml += '  />\n';
      }
      
      // Add Gather for DTMF input
      twiml += '  <Gather numDigits="1" action="/handle-digit" method="POST">\n';
      twiml += '    <Say>Press 1 to leave a voicemail. Press 2 to try another number.</Say>\n';
      twiml += '  </Gather>\n';
    } else {
      // Handle outbound calls
      twiml += '  <Say>This call is being connected. Please wait.</Say>\n';
      if (recordingEnabled) {
        twiml += '  <Record \n';
        twiml += '    maxLength="3600" \n';
        twiml += '    playBeep="true" \n';
        twiml += '    recordingStatusCallback="/recording-status" \n';
        twiml += '  />\n';
      }
    }

    twiml += '</Response>';

    // Log call details
    console.log(`Handling ${direction} call: ${callSid} from ${from} to ${to}`);

    return new Response(twiml, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/xml",
      },
    });
  } catch (error) {
    console.error("Error handling call:", error);
    return new Response(
      '<?xml version="1.0" encoding="UTF-8"?><Response><Say>An error occurred processing your call.</Say></Response>',
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/xml",
        },
      }
    );
  }
});