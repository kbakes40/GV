import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const params = await req.formData();
    const digits = params.get("Digits");
    const callSid = params.get("CallSid");

    let twiml = '<?xml version="1.0" encoding="UTF-8"?>\n<Response>\n';

    switch (digits) {
      case "1":
        // Handle voicemail
        twiml += '  <Say>Please leave your message after the beep.</Say>\n';
        twiml += '  <Record \n';
        twiml += '    maxLength="300" \n';
        twiml += '    playBeep="true" \n';
        twiml += '    recordingStatusCallback="/recording-status" \n';
        twiml += '    transcribe="true" \n';
        twiml += '    transcribeCallback="/transcription-status" \n';
        twiml += '  />\n';
        break;
      
      case "2":
        // Try another number
        twiml += '  <Say>Transferring your call to an alternative number.</Say>\n';
        twiml += '  <Dial>+1234567890</Dial>\n'; // Replace with actual fallback number
        break;
      
      default:
        twiml += '  <Say>Invalid input received. Goodbye.</Say>\n';
        twiml += '  <Hangup />\n';
    }

    twiml += '</Response>';

    console.log(`Handling digit ${digits} for call ${callSid}`);

    return new Response(twiml, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/xml",
      },
    });
  } catch (error) {
    console.error("Error handling digit:", error);
    return new Response(
      '<?xml version="1.0" encoding="UTF-8"?><Response><Say>An error occurred processing your input.</Say></Response>',
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/xml",
        },
      }
    );
  }
});